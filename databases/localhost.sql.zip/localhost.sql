-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Oct 04, 2016 at 05:57 PM
-- Server version: 5.6.28
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carepool`
--
DROP DATABASE `carepool`;
CREATE DATABASE IF NOT EXISTS `carepool` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `carepool`;

-- --------------------------------------------------------

--
-- Table structure for table `dTrips`
--

CREATE TABLE `dTrips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `olat` float(10,6) NOT NULL,
  `olng` float(10,6) NOT NULL,
  `dlat` float(10,6) DEFAULT NULL,
  `dlng` float(10,6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `drivers_dTrips`
--

CREATE TABLE `drivers_dTrips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `D_Id` bigint(20) UNSIGNED NOT NULL,
  `DT_Id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `drivers_riders`
--

CREATE TABLE `drivers_riders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `D_Id` bigint(20) UNSIGNED NOT NULL,
  `R_Id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rTrips`
--

CREATE TABLE `rTrips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `olat` float(10,6) NOT NULL,
  `olng` float(10,6) NOT NULL,
  `dlat` float(10,6) NOT NULL,
  `dlng` float(10,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `riders`
--

CREATE TABLE `riders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `riders_rTrips`
--

CREATE TABLE `riders_rTrips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `R_Id` bigint(20) UNSIGNED NOT NULL,
  `RT_Id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dTrips`
--
ALTER TABLE `dTrips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `drivers_dTrips`
--
ALTER TABLE `drivers_dTrips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `drivers_riders`
--
ALTER TABLE `drivers_riders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `rTrips`
--
ALTER TABLE `rTrips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `riders`
--
ALTER TABLE `riders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `riders_rTrips`
--
ALTER TABLE `riders_rTrips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dTrips`
--
ALTER TABLE `dTrips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `drivers_dTrips`
--
ALTER TABLE `drivers_dTrips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `drivers_riders`
--
ALTER TABLE `drivers_riders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rTrips`
--
ALTER TABLE `rTrips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `riders`
--
ALTER TABLE `riders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `riders_rTrips`
--
ALTER TABLE `riders_rTrips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;--
-- Database: `carepool_test`
--
DROP DATABASE `carepool_test`;
CREATE DATABASE IF NOT EXISTS `carepool_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `carepool_test`;

-- --------------------------------------------------------

--
-- Table structure for table `dTrips`
--

CREATE TABLE `dTrips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `olat` float(10,6) NOT NULL,
  `olng` float(10,6) NOT NULL,
  `dlat` float(10,6) DEFAULT NULL,
  `dlng` float(10,6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `drivers_dTrips`
--

CREATE TABLE `drivers_dTrips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `D_Id` bigint(20) UNSIGNED NOT NULL,
  `DT_Id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `drivers_riders`
--

CREATE TABLE `drivers_riders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `D_Id` bigint(20) UNSIGNED NOT NULL,
  `R_Id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rTrips`
--

CREATE TABLE `rTrips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `olat` float(10,6) NOT NULL,
  `olng` float(10,6) NOT NULL,
  `dlat` float(10,6) NOT NULL,
  `dlng` float(10,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `riders`
--

CREATE TABLE `riders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `riders_rTrips`
--

CREATE TABLE `riders_rTrips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `R_Id` bigint(20) UNSIGNED NOT NULL,
  `RT_Id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dTrips`
--
ALTER TABLE `dTrips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `drivers_dTrips`
--
ALTER TABLE `drivers_dTrips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `drivers_riders`
--
ALTER TABLE `drivers_riders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `rTrips`
--
ALTER TABLE `rTrips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `riders`
--
ALTER TABLE `riders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `riders_rTrips`
--
ALTER TABLE `riders_rTrips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dTrips`
--
ALTER TABLE `dTrips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `drivers_dTrips`
--
ALTER TABLE `drivers_dTrips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `drivers_riders`
--
ALTER TABLE `drivers_riders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rTrips`
--
ALTER TABLE `rTrips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `riders`
--
ALTER TABLE `riders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `riders_rTrips`
--
ALTER TABLE `riders_rTrips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
